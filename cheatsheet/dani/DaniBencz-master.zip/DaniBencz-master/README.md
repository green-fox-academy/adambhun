# Other projects

> The webpage done for 0.homework
<h5>https://danibencz.github.io/<h5>

**To Do App**
<h5>https://github.com/DaniBencz/todo-app<h5>

*The Wanderer*
<h5>https://github.com/DaniBencz/wanderer-typescript<h5>

image-slider
<h5>https://github.com/DaniBencz/image-slider<h5>
  
