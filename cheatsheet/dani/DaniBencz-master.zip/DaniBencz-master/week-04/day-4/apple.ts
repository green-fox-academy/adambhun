'use strict';

export class Apple {
  getApple(): string{
    return 'apple';
  }
}