'use strict';

let a:number = 0;

console.log(a);

for(let i = 0; i < 250; i++){
    a += 2;
    console.log(a);
}


// Create a program that prints all the even numbers between 0 and 500