'use strict';

let number: number = 15;

for(let i: number = 0; i < 10; i++){
    let result:number = (i+1)*number;
    console.log(result);
}
