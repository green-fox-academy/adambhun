'use strict';

let a: string = "I won't cheat on the exam!"
let i: number = 0;

for (i = 0; i < 100; i++){
    console.log(a);
}
