'use strict';

let lineCount: number = 6;
let star: string = "*";
let a: string ="";

for (let i:number = 0; i < lineCount; i++){
    a = a + star;
    console.log(a);
}
