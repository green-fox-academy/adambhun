'use strict';

let a:number = 0;

console.log(a);

for(a; a <= 500; a += 2){
    console.log(a);
}
