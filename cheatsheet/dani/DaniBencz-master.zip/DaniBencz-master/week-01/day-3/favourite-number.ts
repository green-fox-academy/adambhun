'use strict';

let favoriteNumber: number = 42;
console.log("My favorite number is " + favoriteNumber + ".");
