'use strict';

//chaneged values to my own ;)

let massInKg: number = 67.5;
let heightInM: number = 1.70;
let BMI: number = massInKg/heightInM**2;

//BMI = kg/m*m

console.log(BMI.toFixed(1));