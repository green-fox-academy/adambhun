'use strict';

console.log ("Daniel Bencz");
console.log (32);
console.log (1.70);
