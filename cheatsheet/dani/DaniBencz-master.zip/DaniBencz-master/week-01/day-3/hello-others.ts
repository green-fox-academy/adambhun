'use strict';

console.log ("Hello Ádám!");
console.log ("Hello Orsi!");
console.log ("Hello Max!");
