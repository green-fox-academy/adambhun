'use strict';

let myName: string = "Dani";
let myAge: number = 32;
let myHeight: number = 1.70;
let ifMarried: Boolean = true;

console.log(myName);
console.log(myAge);
console.log(myHeight);
console.log(ifMarried);