'use strict';

let a = 22;
let b = 13;

console.log (a+b);
console.log (a-b);
console.log (a*b);
console.log (a/b);
console.log (a%b);