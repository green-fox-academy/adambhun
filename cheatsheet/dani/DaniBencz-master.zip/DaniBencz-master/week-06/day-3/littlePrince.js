'use strict';

var king = document.getElementById('b325');
console.log('king', king);
var lamplighter = document.querySelector('.b329');
console.log('lamplighter', lamplighter);
var asteroids = document.querySelectorAll('div.asteroid');
for (var i = 0; i < asteroids.length; i++) {
    console.log('asteroid', asteroids[i]);
}
