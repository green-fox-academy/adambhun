'use strict';
export{}

let magicNumbers = [1, 3, 5, 7];
console.log(magicNumbers[2]);

// -  Create a variable named `magicNumbers`
//    with the following content: `[1, 3, 5, 7]`
// -  Print the third element of `magicNumbers`

