'use strict';
export{}

let r = [54, 23, 66, 12];

let x :number = r[1] + r[2];

console.log(x);

// -  Create a variable named `r` with the following content: `[54, 23, 66, 12]`
// -  Print the sum of the second and the third element