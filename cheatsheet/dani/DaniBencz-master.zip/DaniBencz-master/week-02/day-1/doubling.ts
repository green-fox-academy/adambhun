'use strict';

let baseNum :number = 123;

function doubling (input: number): number {
    return input * 2;
}

console.log(doubling(baseNum));

// -  Create a variable named `baseNum` and assign the value `123` to it
// -  Create a function called `doubling` that doubles it's input parameter and returns with an integer
// -  Log the result of `doubling(baseNum)` to the console