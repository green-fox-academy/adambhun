'use strict';
export{}

function printParams (a, b, c = "hello", d?){
    console.log(a, b, c, d);
}

printParams(3, "fox");

// -  Create a function called `printParams`
//    which logs to the console the input parameters
//    (can have multiple number of arguments)

