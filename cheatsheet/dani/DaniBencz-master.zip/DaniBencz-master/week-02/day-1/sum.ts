'use strict';
export{}

function sum (a){
    let b: number = 0;
    for (let i: number = 0; i <= a; i++){
        b = b + i;
    }
    return b;
}

console.log(sum(5));



// -  Write a function called `sum` that sum all the numbers until the given parameter
// -  The function should return the result

